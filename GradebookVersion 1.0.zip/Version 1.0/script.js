function addGradeField(category) {
	var gradesList = document.getElementById(category+"Grades");
	var newGrade = document.createElement("li");
	var idCode = gradesList.childNodes.length - 2;
	
	/// A little quick fix to fix IDs. It messes up because the active marker throws off the count for everything after the first one...
	if(idCode > 1)
		idCode = (idCode+1)/2;
	
	newGrade.setAttribute("id",category+"Grade"+idCode);
	newGrade.setAttribute("class", "Grade");
	newGrade.innerHTML = '<input type="text"class="GradeName" value="'+category+' #"/><input type="text" class="GradeValue" id="'+category+'GradeValue'+idCode+'" value = "100" />';
	
	var activeMarker = document.createElement('input');    
	activeMarker.type = "checkbox";
	activeMarker.id = ""+category+"GradeMarker"+idCode;
	activeMarker.setAttribute("class", "ActiveMarker");
	activeMarker.setAttribute("Checked", "True");	
	gradesList.appendChild(activeMarker);
	
	gradesList.appendChild(newGrade);
}

function init(){
	setInterval('calculateTotal()', 1000);
}

function calculateTotal()
{
	var homeworkGrade = calculateGrade("Homework");// * (parseFloat(document.getElmenentById("HomeworkPercentage").value) / 100);
	var quizGrade = calculateGrade("Quiz"); //* (parseFloat(document.getElmenentById("QuizPercentage").value) / 100);
	
	var homeworkPercentage = parseFloat(document.getElementById("HomeworkPercentage").value)/100.0;
	
	var quizPercentage = parseFloat(document.getElementById("QuizPercentage").value)/100.0;

	var total = ( (homeworkGrade * homeworkPercentage) + (quizGrade * quizPercentage) ) * 100.0;
	
	document.getElementById("TotalTotalSummary").innerHTML = total;
//	var testGrade = calculateGrade("Test");
}

function calculateGrade(category)
{
	// Todo: add grade/total field, instead of assuming it's out of 100...
//	var gradeValue = document.getElementById('myText');
//	myTextField.value != ""

	var i = 1;

        var gradeValue = document.getElementById(category+"GradeValue"+i);
        
        var grade = 0;
        var total = 0;
        
       	while( gradeValue != null){
       		// Do stuff with the grade value. 
       		
       		var activeCheck = document.getElementById(category+"GradeMarker"+i);
       		if(activeCheck.checked){		// Check if we shoudl include that grade in...
	       		grade+=parseFloat(gradeValue.value);	// Note: Do parseInt here instead?
	       		total+=100;
       		}
       		i++;
       		gradeValue = document.getElementById(category+"GradeValue"+i);
	}
	document.getElementById(category+"Total").innerHTML = ""+grade+"/"+total;
	document.getElementById(category+"TotalSummary").innerHTML = ""+grade+"/"+total;
	return grade/total;
}

